<?php
namespace Bluethink\Product\Controller\Index;

class ConfigurableProduct extends \Magento\Framework\App\Action\Action
{
	protected $_pageFactory;

	public function __construct(
		\Magento\Framework\App\Action\Context $context,
		\Magento\Framework\View\Result\PageFactory $pageFactory)
	{
		$this->_pageFactory = $pageFactory;
		
		return parent::__construct($context);
	}

	public function execute()
	{

$objectManager = \Magento\Framework\App\ObjectManager::getInstance();

$product = $objectManager->create('Magento\Catalog\Model\Product');


$sku = 'sku11'; 
$product->setSku($sku);
$product->setName('Shirt Casual');
$product->setWeight(25);
$product->setPrice(100);
$product->setDescription('description'); 
$product->setAttributeSetId(4); 
$product->setCategoryIds(array(35)); 
$product->setStatus(1);
$product->setVisibility(4); 
$product->setTaxClassId(1); 
$product->setTypeId('configurable'); 
$product->setStoreId(1); 
$product->setWebsiteIds(array(1)); 
$product->setVisibility(4); 
$product->setImage('/var/images/image2.jpg'); 
$product->setSmallImage('/var/images/image2.jpg'); 
$product->setThumbnail('/var/images/image2.jpg'); 
$product->setStockData(array(
'use_config_manage_stock' => 0, 
'manage_stock' => 1, 
'min_sale_qty' => 1, 
'max_sale_qty' => 2,
'is_in_stock' => 1, 
'qty' => 1000
)
);



$product->save();

$childrenIds = [2, 3, 4]; 
$associated = [];
$position = 0;
foreach ($childrenIds as $productId)
{

$position++;

$linkedProduct = $objectManager->get('\Magento\Catalog\Api\ProductRepositoryInterface')->getById($productId);

$productLink = $objectManager->create('\Magento\Catalog\Api\Data\ProductLinkInterface');

$productLink->setSku($product->getSku())
->setLinkType('associated') 
->setLinkedProductSku($linkedProduct->getSku()) 
->setLinkedProductType($linkedProduct->getTypeId())
->setPosition($position) 
->getExtensionAttributes()
->setQty(1);
$associated[] = $productLink;

}

$product->setProductLinks($associated);
$product->save();
$categoryIds = array('2','3'); 
$category = $objectManager->get('Magento\Catalog\Api\CategoryLinkManagementInterface');

$category->assignProductToCategories($sku, $categoryIds);

if ($product->getId())
{
echo "Product Created";
}
else

{
	echo "Product is not created ";
}


}
} 